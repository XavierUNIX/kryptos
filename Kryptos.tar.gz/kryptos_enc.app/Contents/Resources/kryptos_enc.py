import syn_enc
